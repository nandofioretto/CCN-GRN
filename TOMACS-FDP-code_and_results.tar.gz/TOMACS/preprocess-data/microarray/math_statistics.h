#ifndef _MATH_STATISTICS_H
#define _MATH_STATISTICS_H

#include <iostream>
#include <cmath>
#include <vector>

typedef std::vector <double> RV;
typedef std::vector <double> values;

namespace statistics {
  
  static int const PEARSON_CORRELATION = 1;
  static int const SPEARMAN_RANK = 2;
  static int const MVAR = 6;
  static int const MI_GAUSSIAN = 10;

  static int const MI_ADAPTIVE_PARTITIONING = 11;
  static int const MI_GAUSSIAN_NO_COPULA = 12;
  
  //static double const M_PI = 3.14159265358979323846;

  std::vector<int> rank (std::vector <double> x);
  // Correlation coefficients
  double pearson_correlation (RV X, RV Y);
  double spearman_rank (RV X, RV Y);

  
  double average (std::vector<double> data, bool rm_NA=false);
  double median (std::vector<double> data, bool sorted=false);
  double std_dev (std::vector<double> x, bool rm_NA=false);
  double interQuartileRange(std::vector <double> data);
  double normalPDF(double dx, double sigma);
  double multinormalPDF(double dx, double dy, double sigmaX, double sigmaY);
  double gaussian_kernel (std::vector <double> x, std::vector <double> y, size_t i, double sigmaX, double sigmaY);
  double gaussian_CDF (double x);

  // Mutual Information Based Approaches
  double MI(RV X, RV Y, int type);
  
}

#endif
