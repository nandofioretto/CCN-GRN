#include "timeserie.h"
#include "microarray.h"
#include "probe.h"

using namespace std;

Timeserie::Timeserie (string path, int model_no) {
  type = Microarray::EXP_TIMESERIE;
  Timeserie::init (path, model_no);
  Microarray::compute_variance();
  Microarray::compute_bandwidth();
}//-

Timeserie::Timeserie 
(int argc, char* argv[], int& parse_pos) {

  type = Microarray::EXP_TIMESERIE;
  string data_path;
  int numof_reads = 1;
  for (; parse_pos < argc; parse_pos++) {
    if (!strcmp ("--microarray-timeserie", argv[parse_pos])) {
      data_path = argv[++parse_pos];
      numof_reads = atoi(argv[++parse_pos]);
      Timeserie::init (data_path, numof_reads);
      Microarray::compute_variance();
      Microarray::compute_bandwidth();
      break;
    }
  }

}//-

Timeserie::Timeserie 
(vector< vector< double > > _data,  vector< double > times) {
  
  type = Microarray::EXP_TIMESERIE;

  for (int g=0; g<_data[0].size(); g++) {
    char gname[24];
    sprintf (gname, "G%i", g+1);
    gene_labels.push_back(gname);
  }
  size_t nprobes = gene_labels.size();
 
  for (int t = 0; t < _data.size(); t++) {
    vector< double > t_genes;
    times.push_back (times[t]);
    microarray array (nprobes);
    for (int p = 0; p < nprobes; p++) {
      Probe pro(_data[t][p]);
      array[p] = pro;
    }
    microarray_vector.push_back (array);
  }
  Microarray::normalize();
}//-

Timeserie::Timeserie (const Timeserie& other) {
  times = other.times;
}//-

Timeserie& 
Timeserie::operator= (const Timeserie& other) {
  if (this != &other) {
    times = other.times;
  }
  return *this;
}//-

// This function will load only the first experiment.
void
Timeserie::init (string data_path, int data_no) {
  ifstream data_file;  
  data_file.open (data_path.c_str());
  assert (data_file.is_open()); 
  string line, token;
  
  { //- Read Header
    getline (data_file, line);
     stringstream sline (line);

    while (!sline.eof()) {
      sline >> token;
      size_t del_l = token.find_first_of("\"");
      size_t del_r = token.find_last_of("\"");
      if (del_l != string::npos && del_r != string::npos)
	token = token.substr (del_l+1, del_r-1);

      if (!token.compare("Time")) 
	; // do nothing
      else 
	gene_labels.push_back(token);
    }
  } //-

  // Read the data set:
  size_t numof_genes = gene_labels.size();
  double probe_val, probe_pval;
  
  // Skip the first #data_no Datasets
  for (int i=0; i < data_no; i++) {
    do {
      getline (data_file, line); // skip first (empty) line
    } while (line.size() > 0);
  }

  while (true) {
    getline (data_file, line);
    if (line.size() <= 0) break; 
    stringstream sline (line);
    microarray single_measurement (numof_genes);
    // first measurement is the time stamp 
    sline >> token;
    times.push_back(atof(token.c_str()));
    // All the rest are the gene probes
    for (int g = 0; g < numof_genes; g++) {
      sline >> token;
      probe_val = atof(token.c_str());
      Probe p(probe_val);
      single_measurement[g] = p;
    }
    microarray_vector.push_back (single_measurement);
  }

}//-

double 
Timeserie::get_time (int pos) const {
  return times[pos];
}//-

double 
Timeserie::get_value (int gene, int time) const {
  return microarray_vector[time][gene].get_value();
}//-

size_t
Timeserie::numof_time_steps() const {
  return times.size();
}//-

void
Timeserie::dump() const {
  cout << "TimeserieData:\n";
  cout << "time\t";
  for (int i = 0; i < gene_labels.size(); i++) 
    cout << gene_labels[i] << "\t";
  cout << endl;

  cout.precision(2);
  for (size_t t = 0; t < times.size(); t++) {
    cout << (int)times[t] << ":\t";
    for (size_t g = 0; g < numof_genes(); g++) {
      cout << microarray_vector[t][g] << "\t";
      //cout << math::round_to_zero(data[kg][tg],2); 
    }
    cout << endl;
  }
  cout << endl;  
}//-
