/* File Adapted from ARACNE v. 2.0 */
#ifndef GN_PROBE_H
#define GN_PROBE_H

#include <iostream>
#include <fstream>


/***********************************************************
 * Microarrays are really silicon chips that contain probes
 * to detect genes.  Each probe is a tuple containing values
 * and pvalues, and there are n such tuples arranged in an
 * array, indexed by the same numbers which indexes Markers
 * in a set.  Since Markers describe genes, the correspondence
 * is natural.  Associated with each set of Microarrays is
 * also a Marker_Set object.  If the cardinality of the marker
 * set is m, then each Microarray will have m probes
 *  associated with it.
 */
class Probe
{
  double val, pval;
  
  double variance;
  double bandwidth;
  bool active;
  bool control;

  /** deliminator btw probes when they are written to a stream */
  const char* DELIMINATOR;
public:

  Probe(double v = 0.0, double pv = 0.0);
  Probe(const Probe& other);
  Probe& operator= (const Probe& other);
  double get_value() const;
  double get_pvalue() const;
  double get_variance() const;
  double get_bandwidth() const;
  bool is_active() const;
  bool is_constrol() const;
  void set_value(double v);
  void set_pvalue(double pv);
  void set_variance(double var);
  void set_bandwidth(double bw);
  void set_active (bool b=true);
  void set_control (bool b=false);
};

std::ostream & operator << ( std::ostream & out, const Probe & p );

#endif
