#include "probe.h"

using namespace std;

Probe::Probe (double v, double pv) : 
  val(v), pval(pv), DELIMINATOR("\t"), active(true), control(false) {
}//-

Probe::Probe (const Probe& other) { 
  val = other.val;
  pval = other.pval;
  variance =  other.variance;
  bandwidth = other.bandwidth;
  active = other.active;
  control = other.control;
}//-

Probe&
Probe::operator= (const Probe& other) { 
  if (this != &other) {
    val = other.val;
    pval = other.pval;
    variance =  other.variance;
    bandwidth = other.bandwidth;
    active = other.active;
    control = other.control;
  }
  return *this;
}//-

double 
Probe::get_value() const {
  return val; 
}//-

double Probe::get_pvalue() const {
  return pval; 
}//-

double 
Probe::get_variance() const {
  return variance; 
}//-

double Probe::get_bandwidth() const {
  return bandwidth; 
}//-

bool 
Probe::is_active() const {
  return active;
}

bool 
Probe::is_constrol() const {
  return control;
}//-

void Probe::set_value( double v ) {
  val = v; 
}//-

void Probe::set_pvalue( double pv ) {
  pval = pv; 
}//-

void Probe::set_variance( double var ) {
  variance = var; 
}//-

void Probe::set_bandwidth( double bw ) {
  bandwidth = bw; 
}//-

void Probe::set_active( bool b ) {
  active = b; 
}//-

void Probe::set_control( bool b ) {
  control = b; 
}//-


std::ostream& operator << (std::ostream& out, const Probe& p) {
  //out << "(" << p.get_value() << ", " << p.get_pvalue() << ")";
  out << p.get_value() << " ";
  return (out);
}
