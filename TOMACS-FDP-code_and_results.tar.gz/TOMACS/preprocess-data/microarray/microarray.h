/* Microarray Class
 * The first column of the matrix data holds the time stamp when the measurement
 * occurred; the other columns hold the normalized RNA-level measurement for 
 * each gene.
*/
#ifndef GNOFF_MICROARRAY_H
#define GNOFF_MICROARRAY_H

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "probe.h"
class Probe;

typedef std::vector<Probe> microarray;

class Microarray/*Vector*/ {
 protected:
  std::vector<std::string> gene_labels;  
  std::vector <microarray> microarray_vector;
  int type;
 
 public:
  static int const EXP_TIMESERIE = 0;
  static int const EXP_WILDTYPES = 1;
  static int const EXP_KNOCKOUTS = 2;
  static int const EXP_KNOCKDOWNS = 3;
  static int const EXP_MULTIFACTORIAL = 4;

  static int const TYPE_DREAM3 = 10;
  static int const TYPE_DREAM4 = 11;

 public:
  Microarray ();
  Microarray (const Microarray& other);
  Microarray& operator= (const Microarray& other);

  int get_exp_type() const;
  Probe& get_probe (size_t microarray_id, size_t probe_id);
  std::vector <double> get_probes_values (size_t probe_id);
  std::vector <double> get_microarray_values (size_t microarray_id);
  void compute_variance ();
  void compute_bandwidth();
  void compute_variance (size_t probe_id);
  void compute_bandwidth(size_t probe_id);
  size_t numof_vectors() const;
  size_t numof_genes() const;
  std::string get_gene_label( int i );

  void normalize();
  virtual void init (std::string data_path, int model_no=1) = 0;
  virtual void dump() const = 0;
  //virtual std::vector <double> operator[] (int gene) const = 0;

};//-


#endif
