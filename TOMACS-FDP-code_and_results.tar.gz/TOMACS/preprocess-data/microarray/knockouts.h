/* Knockouts Microarray data Class
 * The data is stored in form of a matrix N x N (N=#genes) as follows:
 * Column i holds the normalized RNA-level measurement for genes subjected to
 * to knokcing out gene g_i. 
 * The gene at position [i,i] of the Matrix "data" represents the knocked-out
 * gene.
 *
 * Load Syntax:
 * --microarray-knockouts PATH_OF_DATA
*/

#ifndef GNOFF_KNOCKOUTS_DATA_H
#define GNOFF_KNOCKOUTS_DATA_H

#include <iostream>
#include <string>
#include "microarray.h"

class Knockouts : public Microarray {
 public:
  Knockouts (int argc, char* argv[], int& parse_pos);
  Knockouts (std::string data_path);
  void init (std::string data_path, int model_no=1);
  void dump() const; 
};

#endif
