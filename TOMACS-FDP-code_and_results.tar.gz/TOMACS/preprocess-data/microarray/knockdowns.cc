#include <cassert>
#include <vector>
#include <fstream>
#include <sstream>

#include "knockdowns.h"
#include "microarray.h"
#include "probe.h"

using namespace std;

Knockdowns::Knockdowns (string path) {
  type = Microarray::EXP_KNOCKDOWNS;
  Knockdowns::init (path);
  Microarray::compute_variance();
  Microarray::compute_bandwidth();
}//-

Knockdowns::Knockdowns 
(int argc, char* argv[], int& parse_pos) {

  type = Microarray::EXP_KNOCKDOWNS;
  string data_path;
  for (; parse_pos < argc; parse_pos++) {
    if (!strcmp ("--microarray-knockdowns", argv[parse_pos])) {
      data_path = argv[++parse_pos];
      Knockdowns::init (data_path);
      Microarray::compute_variance();
      Microarray::compute_bandwidth();
      break;
    }
  }

}//-

// This function will load only the first experiment.
void
Knockdowns::init (string data_path, int model_no) {
  ifstream data_file;  
  data_file.open (data_path.c_str());
  assert (data_file.is_open()); 
  string line, token;
  int type = Microarray::TYPE_DREAM4;

  { //- Read Header
    getline (data_file, line);
     stringstream sline (line);

    while (!sline.eof()) {
      sline >> token;
      size_t del_l = token.find_first_of("\"");
      size_t del_r = token.find_last_of("\"");
      if (del_l != string::npos && del_r != string::npos)
	token = token.substr (del_l+1, del_r-1);

      // Skip line Token if DREAM3 format
      if (token == "strain") {
	type = Microarray::TYPE_DREAM3;
	continue;
      }	
      gene_labels.push_back(token);
    }
  } //-
  
  // Read the data set:
  // Skip first line (wt) if file is of DREAM3 format 
  if (type == Microarray::TYPE_DREAM3)
    getline (data_file, line);

  size_t numof_genes = gene_labels.size();
  double probe_val, probe_pval;
  size_t control = 0;
  do {
    getline (data_file, line);
    stringstream sline (line);
    microarray single_measurement (numof_genes);

    // Skip first token if file is of DREAM3 format
    if (type == Microarray::TYPE_DREAM3)
      sline >> token;

    for (int g = 0; g < numof_genes; g++) {
      sline >> token;
      probe_val = atof(token.c_str());
      Probe p(probe_val);
      if (g == control)
	p.set_control(true);
      single_measurement[g] = p;
    }
    microarray_vector.push_back (single_measurement);
    control++;

  } while (line.size() > 0 && microarray_vector.size() < numof_genes);
}//-


void
Knockdowns::dump() const {
  cout << "KnockdownsData:\n";
  for (int i = 0; i < gene_labels.size(); i++) 
    cout << gene_labels[i] << "\t";
  cout << endl;

  cout.precision(2);
  for (size_t kg = 0; kg < numof_genes(); kg++) {
    for (size_t tg = 0; tg < numof_genes(); tg++) {
      cout << microarray_vector[kg][tg];
      //cout << math::round_to_zero(data[kg][tg],2); 
      if (kg == tg) cout << "*\t"; 
      else cout << "\t";
    }
    cout << endl;
  }
  cout << endl;  
}//-
