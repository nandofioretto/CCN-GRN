#!/bin/bash

# Paths
mf_file="/Users/ffiorett/Research/SystemBio/GRN_inference/Data/Training/Ecoli/size100/net1/multifactorial.tsv"
ko_file="/Users/ffiorett/Research/SystemBio/GRN_inference/Data/Training/Ecoli/size100/net1/knockouts.tsv"

./preprocess \
    --microarray-mf ${mf_file} \
    --microarray-ko ${ko_file} \
    --path-out "Ecoli1"
