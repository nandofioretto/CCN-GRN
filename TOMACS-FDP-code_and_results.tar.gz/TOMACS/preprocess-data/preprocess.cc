#include <iostream>
#include <vector>
#include <string>
#include <cassert>

#include "multifactorial.h"
#include "knockouts.h"

using namespace std;


int main (int argc, char* argv[])
{
  string path_mf, path_ko, path_out;
  
  for( int i = 0; i < argc; i++ )
  {
    if (!strcmp ("--microarray-mf", argv[ i ])) {
      path_mf = argv[ ++i ];
    }
    if (!strcmp ("--microarray-ko", argv[ i ])) {
      path_ko = argv[ ++i ];
    }
    if (!strcmp ("--path-out", argv[ i ])) {
      path_out = argv[ ++i ];
    }
  }
  
  /* Opening Out Streams */
  string expr_data = path_out + "_expression_data.tsv";
  string chip_feat = path_out + "_chip_features.tsv";
  string tf_data = path_out + "_transcription_factors.tsv";
  string gene_names = path_out + "_gene_names.tsv";
  ofstream os_data (expr_data.c_str(), ios::out);
  ofstream os_chip (chip_feat.c_str(), ios::out);
  ofstream os_tf (tf_data.c_str(), ios::out);
  ofstream os_gn (gene_names.c_str(), ios::out);
  if( !os_data.is_open() || !os_chip.is_open() || !os_tf.is_open() 
      || !os_gn.is_open() ) {
    cout << "Error: cannot access to outfile\n";
    return -1;
  }
  
  string sep = "\t";

  assert( !path_mf.empty() );
  Multifactorial expM( path_mf );
  assert( !path_ko.empty() );
  Knockouts expK( path_ko );
  
  /* Dump Gene Names */
  for( int i = 0; i < expM.numof_genes(); i++ )
  {
    os_gn << expM.get_gene_label( i ) << " ";
    os_data << expM.get_gene_label( i ) << sep;
    os_tf << expM.get_gene_label( i ) << " ";
  }
  os_gn << endl;
  os_data << endl;
  os_tf << endl;

  int repeat = 1;
  /* Dump Network Features */
  os_chip << "Experiment" << sep 
	  << "Perturbations" << sep 
	  << "PerturbationLevels" << sep
	  << "Treatment" << sep 
	  << "DeletedGenes" << sep
	  << "OverexpressedGenes" << sep
	  << "Time" << sep 
	  << "Repeat" << sep 
	  << "ExperimentName" << endl;

  // MULTIFACTORIAL DATA
  for (int k=0; k < expM.numof_vectors(); k++) 
  {
    os_chip << "0" << sep	// Experiment 
	    << "NA" << sep      // Perturbation
	    << "NA" << sep  	// Pert Levels
	    << "NA" << sep  	// Treatment
	    << "NA" << sep  	// Deleted Genes
	    << "NA" << sep  	// Overexpressed
	    << "NA" << sep  	// Time
	    << repeat << sep  	// Repeat
      	    << "mf_"<< repeat << endl; // Exp Name
    repeat++;

    vector <double> values = expM.get_microarray_values( k );
    os_data << values[ 0 ];
    for (int i=1; i<values.size(); i++)
      os_data << "\t" << values[i];
    os_data << endl;
    //cout << "MULTIFACTORIAL Microarray " << exp_no-1 << " generated\n";
  }

  // KNOCKOUTS DATA
  repeat = 1;
  for (int k=0; k < expK.numof_vectors(); k++) 
  {    
    os_chip << "0" << sep	// Experiment 
	    << "P" << k << sep	// Perturbation
	    << "NA" << sep  	// Pert Levels
	    << "NA" << sep  	// Treatment
	    << expK.get_gene_label( k ) << sep  	// Deleted Genes
	    << "NA" << sep  	// Overexpressed
	    << "NA" << sep  	// Time
	    << repeat << sep  	// Repeat
      	    << "ko_"<< k << endl; // Exp Name
    
    vector <double> values = expK.get_microarray_values( k );
    os_data << values[0];
    for (int i=1; i<values.size(); i++) 
      os_data << "\t" << values[i];
    os_data << endl;
  }

  os_data.close();
  os_chip.close();
  os_tf.close();
  os_gn.close();

  return 0;
}//-
